import pygame, pygame.mixer
import pygame
from pygame import Surface
from pygame.image import load
from pygame.locals import *
from pygame.mixer import music
from pygame.rect import Rect
from pygame.sprite import Group, Sprite, OrderedUpdates, LayeredUpdates
from pygame.color import Color
from random import randint, choice
from pygame.font import Font
from os.path import join
from pygame.transform import rotate
import locals
from microgame import Microgame

def make_game():
    return DDR()

def title():
    return 'Dance Dance Revolution: SAAST Edition'

def thumbnail():
    return join('games','DDR','DDR_Images','downclear.png')

def hint():
    'Dance'

def _load_image(name, x, y):
    '''
    Loads an image file, returning the surface and rectangle corresponding to
    that image at the given location.
    '''
    try:
        image = load(name)
        if image.get_alpha is None:
            image = image.convert()
        else:
            image = image.convert_alpha()
    except pygame.error, msg:
        print 'Cannot load image: {}'.format(name)
        raise SystemExit, msg
    rect = image.get_rect().move(x, y)
    return image, rect

class arrow(Sprite):

    def __init__(self,game,direction, x, y,vx,vy):
        Sprite.__init__(self)
        self.image, self.rect=_load_image(join('games','DDR','DDR_Images','upclear.png'),x,y)
        self.direction=direction
        
        if self.direction=='left':
            self.image=rotate(self.image,90)
        
        elif self.direction=='down':
            self.image=rotate(self.image,180)
            

        elif self.direction=='right':
            self.image=rotate(self.image,-90)
    
        else:
            self.image=self.image

        self.area=game.rect
        self.game=game

    def update(self):
        self.rect=self.rect.move(0,0)
        

class moving_arrow(Sprite):

    def __init__(self,game,direction,x,y,vx,vy):
        Sprite.__init__(self)
        self.image, self.rect=_load_image(join('games','DDR','DDR_Images','upclear.png'), x, y)
        
        self.direction=direction
        
        if self.direction=='right':
            self.image=rotate(self.image,-90)
##            event.type==K_Right

        elif self.direction=='down':
            self.image=rotate(self.image,180)
##            event.type=K_DOWN

        elif self.direction=='left':
            self.image=rotate(self.image,90)
##            event.type=K_LEFT

        else:
            self.image=self.image
##            event.type=K_UP
            
        self.vx=vx
        self.vy=vy
        self.area=game.rect
        self.game=game

    def update(self):
        self.rect=self.rect.move(self.vx,self.vy)
        print'mat'
        if self.rect.colliderect(self.game.arrow1.rect) and self.game.arrow1.rect.center[1]-self.rect.center[1]<=30:
            print'wade'
            for event in pygame.event.get():
                if event.type==KEYDOWN and  event.key==K_LEFT:
                    print 'cat'
                else:
                    print'bat'
        if self.game.arrow2.rect.center[1]-self.rect.center[1]<=2:
            for event in pygame.event.get():
                if event.type==KEYDOWN and event.key==K_DOWN:
                    self.sprites.remove(self)
                else:
                    self.game.lose()
        if self.game.arrow3.rect.center[1]-self.rect.center[1]<=2:
            for event in pygame.event.get():
                if event.type==KEYDOWN and event.key==K_UP:
                    self.sprites.remove()
                else:
                    self.game.lose()
        if self.game.arrow4.rect.center[1]-self.rect.center[1]<=2:
            for event in pygame.event.get():
                if event.type==KEYDOWN and event.key==K_RIGHT:
                    self.kill()
                else:
                    self.game.lose()
        else:
            print
            
    


class DDR(Microgame):

    def __init__(self):
        Microgame.__init__(self)
        self.rect=Rect(0,0, locals.WIDTH, locals.HEIGHT)
        self.arrow1=arrow(self,'left',50,50,0,0)
        self.arrow2=arrow(self,'down',150,50,0,0)
        self.arrow3=arrow(self,'up',250, 50,0,0)
        self.arrow4=arrow(self,'right',350,50,0,0)
        self.sprites=Group([self.arrow1,self.arrow2,self.arrow3,self.arrow4])
        self.timesincearrow=0

    def time_elapsed(self):
        self.timesincearrow=pygame.time.get_ticks()

    def start(self):
        self.time_elapsed()

    def stop(self):
        pass

    
        
    def update(self):
        time=pygame.time.get_ticks()
        self.sprites.update()
        if time-self.timesincearrow>1000:
            num=randint(0,3)
            if num==0:
                self.sprites.add(moving_arrow(self,'left',50,768,0,-30))
            elif num==1:
                self.sprites.add(moving_arrow(self,'down',150,768,0,-30))
            elif num==2:
                self.sprites.add(moving_arrow(self,'up',250,768,0,-30))
            elif num==3:
                self.sprites.add(moving_arrow(self,'right',350,768,0,-30))
                
            self.time_elapsed()
        for event in pygame.event.get():
            if event.type==KEYUP and event.key==K_q:
                self.lose()
        
            
##        self.sprites.add(moving_arrow.new_arrows())
    def render(self,surface):
        surface.fill(Color(0,0,0))
        self.sprites.draw(surface)
        
        
        
                    
        
                    
                
        
        

        
            


                                           
